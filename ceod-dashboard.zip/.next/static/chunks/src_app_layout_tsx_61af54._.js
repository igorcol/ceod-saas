(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__9a168d._.css",
    "static/chunks/node_modules_f9652b._.js",
    "static/chunks/src_3f2c2d._.js"
  ],
  "source": "dynamic"
});
