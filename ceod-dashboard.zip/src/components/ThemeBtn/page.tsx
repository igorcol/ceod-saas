"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";

export default function Page() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // Evita erro de hidratação
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return <div className="w-10 h-10 bg-gray-200 dark:bg-gray-800 animate-pulse rounded-full" />;

  return (
    <button
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      className="p-2 border rounded"
    >
      {theme === "dark" ? "🌞 Modo Claro" : "🌙 Modo Escuro"}
    </button>
  );
}
