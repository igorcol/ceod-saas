
export default function Page() {
    return (
        <h1>INGRESSOS</h1>
    )
}