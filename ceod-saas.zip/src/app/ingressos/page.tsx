

const page: React.FC = () => {
    return (
        <div >
           <h1>Ingressos</h1>
        </div>
    );
};

export default page;