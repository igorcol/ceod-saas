(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_spreadsheet_page_tsx_134c45._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_spreadsheet_page_tsx_134c45._.js",
  "chunks": [
    "static/chunks/node_modules_xlsx_xlsx_mjs_ad7550._.js",
    "static/chunks/node_modules_928a2a._.js",
    "static/chunks/src_d26250._.js"
  ],
  "source": "dynamic"
});
