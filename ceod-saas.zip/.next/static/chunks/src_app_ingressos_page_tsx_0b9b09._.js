(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_ingressos_page_tsx_0b9b09._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_ingressos_page_tsx_0b9b09._.js",
  "chunks": [
    "static/chunks/_80e222._.js"
  ],
  "source": "dynamic"
});
