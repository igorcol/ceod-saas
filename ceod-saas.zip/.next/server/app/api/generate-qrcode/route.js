const CHUNK_PUBLIC_PATH = "server/app/api/generate-qrcode/route.js";
const runtime = require("../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_1ba4f3._.js");
runtime.loadChunk("server/chunks/[root of the server]__9636ea._.js");
runtime.loadChunk("server/chunks/_0277fd._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/api/generate-qrcode/route/actions.js [app-rsc] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/generate-qrcode/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
